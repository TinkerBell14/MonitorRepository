﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Data;
using System.Configuration;

namespace ProcessMoniterJob.DataAccess
{
    public class MonitorRepository
    {
        private SqlConnection con;
        private SqlCommand com;
        string jobName = "ProcessMonitor";
        private string connStr = null;
        DateTime? updatedAt = null;


        public MonitorRepository()
        {
            connStr = ConfigurationManager.ConnectionStrings["connStr"].ToString();
          
        }

        private bool AddProcessDetailToDB(int id, string name, DateTime startTime, long virtualMemorySize)
        {
            try
            {
                var query = string.Empty;
               
                if (!IsProcessExist(id))
                {
                    query = "insert into ServerProcessess(Id, name, StartDateTime, VirtualMemorySize,CreatedAt) values ({0},'{1}','{2}',{3}, '{4}')";
                    query = string.Format(query, id, name, startTime, virtualMemorySize, DateTime.Now);
                }
                else
                {
                    query = "update ServerProcessess set VirtualMemorySize={0}, UpdatedAt='{1}' where Id={2}";
                    query = string.Format(query, virtualMemorySize, updatedAt, id);
                }
              
                
                com = new SqlCommand(query, con);
                com.CommandType = CommandType.Text;


                
                int i = com.ExecuteNonQuery();
                
                if (i >= 1)
                {
                    return true;

                }
                else
                {
                    return false;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }



        public bool PushDataToDB()
        {
            try
            {
                
                var lastRun = GetLastRunTime(jobName);

                if(lastRun <= DateTime.Now.AddMinutes(-1))
                {
                    updatedAt = DateTime.Now;
                    using (con = new SqlConnection(connStr))
                    {
                        Process[] allProcesses = Process.GetProcesses();
                        con.Open();
                        foreach (var process in allProcesses)
                        {
                            try
                            {
                                AddProcessDetailToDB(process.Id, process.ProcessName, process.StartTime, process.VirtualMemorySize64);

                            }
                            catch (Exception ex)
                            {
                                // Log Error
                            }

                        }

                        // Update the process which are not running anymore.
                        UpdateEndedProcess();

                    }
                }
                
            }
            catch (Exception ex)
            {
                //Log Error
                return false;
            }
            finally
            {
                con.Close();
            }


            return true;

        }

        public bool UpdateEndedProcess()
        {
            
            try
            {
                
                var query = string.Empty;

                query = "Update ServerProcessess set EndDateTime='{0}', UpdatedAt='{1}' where  UpdatedAt < '{1}' and EndDateTime is null";
                query = string.Format(query, updatedAt, updatedAt);
                com = new SqlCommand(query, con);
                com.CommandType = CommandType.Text;

                var updated = com.ExecuteNonQuery();
               
            }
            catch (Exception ex)
            {
                //log
                return false;
            }
            return true;
        }
        public bool IsProcessExist(int id)
        {
            SqlDataReader myReader = null;
            try
            {
                var query = string.Empty;

                query = "select top 1 Id from ServerProcessess where Id={0} and EndDateTime is null";
                query = string.Format(query, id);
                com = new SqlCommand(query, con);
                com.CommandType = CommandType.Text;

                myReader = com.ExecuteReader();
                if(myReader.Read())
                {
                    return true;
                }
                else
                {
                    return false;
                }

                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (myReader != null)
                    myReader.Close();
            }
        }

        public DateTime? GetLastRunTime(string jobName)
        {
           
           
            try
            {
                using(con = new SqlConnection(connStr))
                {
                    var query = "select LastRun from Config where jobName='{0}'";
                    query = string.Format(query, jobName);
                    com = new SqlCommand(query, con);
                    com.CommandType = CommandType.Text;


                    con.Open();
                    using (var reader = com.ExecuteReader())
                    {
                        if (reader.Read()) // Don't assume we have any rows.
                        {
                            var lastRun = Convert.ToDateTime(reader["LastRun"]);
                            return lastRun;
                        }
                    }

                    return null;
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }


        public bool UpdateJobLastRun(string jobName)
        {
            try
            {
                using(con = new SqlConnection(connStr))
                {
                    var query = "Update config set LastRun = {0} where jobName={0}";
                    query = string.Format(query, DateTime.Now, jobName);
                    com = new SqlCommand(query, con);
                    com.CommandType = CommandType.Text;


                    con.Open();
                    com.ExecuteNonQuery();
                }
                
               
                return true;
            }
            catch (Exception ex)
            {
                //Log Error
                return false;
            }
            finally
            {
                con.Close();
            }
        }



    }
}
