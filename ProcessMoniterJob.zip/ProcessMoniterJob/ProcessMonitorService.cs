﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProcessMoniterJob.DataAccess;

namespace ProcessMoniterJob
{
    public class ProcessMonitorService
    {
        public void PushProcessessDetailToDB()
        {
            string jobName = "ProcessMonitor";
            MonitorRepository repository = new MonitorRepository();
            repository.PushDataToDB();
            repository.UpdateJobLastRun(jobName);
        }
    }
}
