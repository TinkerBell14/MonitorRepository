﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Diagnostics;
using ProcessMonitorAPI.Models;
using System.ComponentModel;
using ProcessMonitorAPI.Services;
using System.Web.Http.Cors;
using ProcessMonitorAPI.filters;

namespace ProcessMonitorAPI.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    
    public class ProcessController : ApiController
    {
        private ProcessMonitorService service = null;
        public ProcessController(){
            service = new ProcessMonitorService();
        }

        [HttpGet]
        [BasicAuthentication]
        [Route("api/process/getallactive")]
        public List<ProcessDTO> GetAllActive() => service.GetAllActive();


        [HttpGet]
        [BasicAuthentication]
        [Route("api/process/getallactive/filtered")]
        public List<ProcessDTO> GetActiveProcessWithFilter([FromUri]string processName=null, [FromUri]string fromDate=null, [FromUri]string toDate=null) => service.GetActiveProcessWithFilter(processName, fromDate, toDate);


        [HttpGet]
        [BasicAuthentication]
        [Route("api/process/getall/filtered")]
        public List<ProcessDTO> GetProcessWithFilter([FromUri]string processName = null, [FromUri]string fromDate = null, [FromUri]string toDate = null) => service.GetAllProcessWithFilter(processName, fromDate, toDate);




    }
}