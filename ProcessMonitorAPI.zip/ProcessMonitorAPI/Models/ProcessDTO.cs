﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProcessMonitorAPI.Models
{
    public class ProcessDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime StartDateTime { get; set;}
        public long VirtualMemorySize { get; set; }

    }
}