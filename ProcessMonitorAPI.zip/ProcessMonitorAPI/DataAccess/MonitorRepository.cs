﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using ProcessMonitorAPI.Models;

namespace ProcessMonitorAPI.DataAccess
{
    public class MonitorRepository
    {
        private SqlConnection con;
        private SqlCommand com;
        private string constr = ConfigurationManager.ConnectionStrings["connString"].ToString();

       
        public List<ProcessDTO> GetAll(string name = null, string fromDate = null, string toDate = null, bool active = true)
        {
            try
            {
                using (con = new SqlConnection(constr)) { 
                    List<ProcessDTO> processList = new List<ProcessDTO>();

                    var query = GetQuery(name, fromDate, toDate, active);
                    com = new SqlCommand(query, con);
                    com.CommandType = CommandType.Text;


                    com = new SqlCommand(query, con);
                    con.Open();
                    SqlDataReader myReader = com.ExecuteReader();
                    while (myReader.Read())
                    {
                        processList.Add(new ProcessDTO()
                        {
                            Id = Convert.ToInt32(myReader["Id"]),
                            Name = myReader["Name"].ToString(),
                            StartDateTime = Convert.ToDateTime(myReader["StartDateTime"]),
                            VirtualMemorySize = Convert.ToInt64(myReader["VirtualMemorySize"])
                        });

                    }

                    myReader.Close();
                    con.Close();

                    return processList;
                }
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private string GetQuery(string name = null, string fromDate = null, string toDate = null, bool active = true)
        {
            var query = string.Empty;
            string startDateTime = null;
            string endDateTime = null;
            var where = string.Empty;
            bool HasOtherCondition = false;

            if (active)
            {
                query = "select * from ServerProcessess where EndDateTime is null";
                HasOtherCondition = true;
            }
            else
            {
                query = "select * from ServerProcessess";
            }

            if ((name != null || fromDate != null && toDate != null) && !active)
            {
                query += " where ";
            }
          
            if (name != null)
            {
                if (HasOtherCondition)
                    name = " and name = '" + name + "'";
                else
                {
                    name = " name = '" + name + "'";
                    HasOtherCondition = true;
                }
            }

            if (fromDate != null)
            {
                startDateTime = " startDateTime >= '" + fromDate + " 00:00:00'";
            }

            if (toDate != null)
            {
                endDateTime = " startDateTime <= '" + toDate + " 11:59:00'";
            }

            if (name != null)
                query += name;

            if (startDateTime != null)
            {
                if(HasOtherCondition)
                    query += " and " + startDateTime;
                else
                {
                    query += startDateTime;
                    HasOtherCondition = true;
                }
                   
            }

            if (endDateTime != null)
            {
                if (HasOtherCondition)
                    query += " and " + endDateTime;
                else
                {
                    query += endDateTime;
                    HasOtherCondition = true;
                }
                   
            }
                
            query += " order by virtualMemorySize desc";
            return query;


        }
    }
}