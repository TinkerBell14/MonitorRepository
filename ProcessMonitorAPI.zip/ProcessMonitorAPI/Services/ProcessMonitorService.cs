﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Diagnostics;
using ProcessMonitorAPI.Models;
using System.ComponentModel;
using ProcessMonitorAPI.DataAccess;

namespace ProcessMonitorAPI.Services
{
    
    public class ProcessMonitorService
    {
        MonitorRepository repository = null;
        public ProcessMonitorService()
        {
            repository = new MonitorRepository();
        }
        
        /// <summary>
        /// Get All the processes order by start datetime of the process
        /// </summary>
        /// <returns></returns>
        public List<ProcessDTO> GetAllActive()
        {
            var processList = new List<ProcessDTO>();
            try
            {
                processList = repository.GetAll();
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return processList;

        }

        /// <summary>
        /// Get all processes of specific type
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public List<ProcessDTO> GetActiveProcessWithFilter(string name = null, string startDate = null, string endDate = null)
        {
            var processList = new List<ProcessDTO>();
            try
            {
                processList = repository.GetAll(name, startDate, endDate, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return processList;

        }

        public List<ProcessDTO> GetAllProcessWithFilter(string name = null, string startDate = null, string endDate = null)
        {
            var processList = new List<ProcessDTO>();
            try
            {
                processList = repository.GetAll( name, startDate, endDate, false);
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return processList;

        }


    }
}