﻿var processDTO = {
    id = null,
    name = null,
    startTime = null,
    virtualMemorySize = null
   
}
var processlist = new processDTO[];

function getAll() {
    $(document).ready(function () {
        $.ajax({
            url: "http://rest-service.guides.spring.io/greeting"
        }).then(function (data) {
            if (data != null) {
                var list = new processDTO[data.length];

                for (i = 0; i < data.length; i++) {
                    var obj = new processDTO();

                    obj.id = data[i].id;
                    obj.name = data[i].name;
                    obj.startTime = data[i].startTime;
                    obj.virtualMemorySize = data[i].virtualMemorySize;
                }


            } else {

            }
           // $('.greeting-id').append(data.id);
            //$('.greeting-content').append(data.content);
        });
    });
}