import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { isDate } from 'util';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent {
  processList: ProcessDTO[];
  name: string;
  startDate: Date;
  endDate: Date;
  error: string;

  constructor(private client: HttpClient) {}

  getAllActive() {
    
    if (this.validate()) {
      this.error = "";

      var url = this.getQuery();

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Basic VGVzdFVzZXI6VGVzdFBhc3N3b3Jk'
        })
      };

     

      this.client.get<ProcessDTO[]>(url, httpOptions).subscribe(result => {
        
        if (result.length > 0) {
          this.processList = result;
          this.error = '';
        } else {
          this.error = 'No Records Found';
        }
        
      }, error => {
          if (error.status == "401")
            this.error = "Unauthorized User";
          else
            this.error = "Internal Server Error";
      });
    } else {
      this.processList = null;
    }
  }

  
  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  validate() {
    // If start date is a valid date
    if (this.startDate) {
      if (isNaN(Date.parse(this.startDate.toString()))) {
        this.error = "Invalid Start date"
        return false;
      }
    }
    // If end date is valid date
    if (this.endDate) {
      if (isNaN(Date.parse(this.endDate.toString()))) {
        this.error = "Invalid End date"
        return false;
      }
     
    }

    return true;
  }

  getQuery() {
    var procesName = '';
    var startDate = '';
    var endDate = '';
    var hasFilter = false;

    var url = "https://localhost:44368/api/process/getallactive";

    if (this.name || this.startDate || this.endDate) {
      url += "/filtered";
      hasFilter = true;
    }

    if (this.name) {
      procesName = "processName=" + this.name;
    }

    if (this.startDate) {
      startDate = "fromDate=" + this.startDate;
    }

    if (this.endDate) {
      endDate = "toDate=" + this.endDate;
    }

    if (hasFilter) {
      if (procesName != '') {
        url += "?" + procesName;
      }

      if (startDate != '') {
        if (procesName != '') {
          url += "&" + startDate;
        } else {
          url += "?" + startDate;
        }

      }

      if (endDate != '') {
        if (procesName != '' || startDate != '') {
          url += "&" + endDate;
        } else {
          url += "?" + endDate;
        }

      }
    }

    return url;
  }

  formateDate(date) {
    return date.replace('T', ' ');
  }


}

interface ProcessDTO {
  id: string;
  name: number;
  startDateTime: Date;
  virtualMemorySize: number;
}

